// write a program in c to input a string and print it
#include<stdio.h>
#include<stdlib.h>
void main(){

    char str[50];

printf("enter the string:");
fgets(str,sizeof str,stdin);
printf("the string you entered is: %s\n", str);
}
