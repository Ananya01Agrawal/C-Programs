#include<stdio.h>
void display()//function definition
{ int b=6;//accessible in the body of display function
    printf("%d",a);
}
int main()
{
   // these both the variables are completerly different
    int a=5;// local variable// accessible in the body of main function
    printf("%d",b);
    display();// we need to call the display for getting the output
    return 0;
}