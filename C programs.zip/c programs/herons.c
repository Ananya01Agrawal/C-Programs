// write a c progtam to display the sides of triangle and calculate its area using herons formula.
#include<stdio.h>
#include<math.h>
int main(){
    float a,b,c,s,area;
    printf("enter the 3 sides of the triangle:");
    scanf("%f %f %f",&a,&b,&c);
    s=(a+b+c)/2;
    area=sqrt(s(s-a)(s-b)(s-c));
    printf("the area of triangle is %f", area);
    return 0;

}