#include<stdio.h>
int main(){
    int a=[]={1,2,3,4,5};//2000
    int* p=&a;
    int n=sizeof(a)/sizeof(a[0]);
    //accessing array elements through pointers
    int i;
    for(i=0;i<n;i++)
    {
    printf("%d",*(a+i));
    //a[4]=*(a+4)
    //p will give the datatype of the variable whom the address is storing
    }//%p is a format specifier used for hexadecimal
    //int,char,
    //*here is dereferncing operator in technical language
    return 0;

}
//two special operators dealing in poiners are
//&(adress of) and *(indirection)operator
int a=10,b=9;
int *p,*q;//having two pointers 
p=&a;//taling address of a
q=&b;//taking the address of b
// address also called the refernce operator
// in p the address of a is 1000 and in q the address of b is 2000
//but we need the value of a and the value of a is 10 so for printing the value of a we use the * dereferncing operator
//
// more than one variable can point to single variable
printf("value of a=%d",a);
printf("address of a =%x",&a);
printf("address of a=%x",p);// pand &a both are same.

