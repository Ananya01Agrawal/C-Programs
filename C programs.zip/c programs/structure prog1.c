// wap to input the details of a input(name,roll,address,dob,cc)and display them using the structure.
//take name and dob of structure type.
#include<stdio.h>
struct name{
    char fname[30],mname[30],lname[30];
};
struct date{
    int dd,mm,yy;
};
struct details{
    int roll;
    char addr[100];
    int contact;
    struct name Name;
    struct date Date;
};

int main()
{
    struct details p;
    scanf("%d",&p.roll);
    scanf("%s",p.addr);
    scanf("%d",&p.contact);
    scanf("%s",p.Name.fname);
    scanf("%s",p.Name.mname);
    scanf("%s",p.Name.lname);
    scanf("%d",&p.Date.dd);
    scanf("%d",&p.Date.mm);
    scanf("%d",&p.Date.yy);
    printf("%d\n %s\n %d\n %s\n %s\n %s\n %d\n %d\n %d\n",p.roll,p.addr,p.contact,p.Name.fname,p.Name.mname,p.Name.lname,p.Date.dd,p.Date.mm,p.Date.yy);
    return 0;

}