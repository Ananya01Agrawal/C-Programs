#include<stdio.h>
#include<string.h>
int main()
{
    //string operations
    //string comparison using inbuilt function
    char str1[]="Hello";
    char str2[]="hello";
    int i,flag=0;
    for(i=0;str2[i]!='0\n'||str1[i]!)
    printf("equal string");
    else
    printf("unequal strings");
   
    return 0;
}