#include<stdio.h>
struct clientdata
{
    int acctnum;
    char lastName[15];
    char FirstName[10];
    double balance;
};
int main(void)
{
    int i;
    struct clientData blankClient={0,"","",0.0};
    FILE *cfPtr;
    if((cfPtr=fopen("credit.dat","wb"))==NULL)
    {
        printf("file couldnot be opened\n");
    }
    else{
        for(i=1;i<=100;i++)
        {
            fwrite(&blankClient,sizeof(struct))
        }
    }


}