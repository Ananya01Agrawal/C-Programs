#include<stdio.h>
int main(){
    int radius, area;
    printf("enter the radius:");
    scanf("%d", radius);
    float pi=3.14;
    
     area=radius*radius*pi;
    printf("the area of the circle %f", area);
    return 0;

}