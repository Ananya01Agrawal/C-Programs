// modularity = breaking the bigger problem into smalleerr
#include<stdio.h>
//return_type function_name(parameter);//declaring user defined functions for adding the two variables

void add(int a,int b);
// need to specify the datatype of every variable in parameter
// defining a function by writing the block of code
void add(int a, int b){

int sum;
sum=a+b;
printf("\nsum of %d and %d is %d",a,b,sum);

}
int main()
{
    int x,y;//local variable has the local scope
    scanf("%d%d",&x,&y);
    add(x,y);//function call
    return 0;
}

    // function declaration
    //function definition
    // function call
    // function call inside the body of main function


