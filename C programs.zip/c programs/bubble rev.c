#include <stdio.h>
int main(){
int temp, i, j, number[5]={6,7,2,1,4};
/* This is the main logic of bubble sort algorithm 
*/
for(i = 0; i < 5; i++){
for(j = 0; j < 5-i-1 ; ++j){
if(number[j] < number[j+1]){
temp = number[j];
number[j] = number[j+1];
number[j+1] = temp;
}
}
}
printf("Sorted Array: ");
for(i=0;i<5;i++)
printf(" %d",number[i]);
return 0;
}