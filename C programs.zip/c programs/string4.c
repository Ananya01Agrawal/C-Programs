// wap to print the each and every character of the string in reverse order.
//wap in c to separate the individual character from a string
#include <stdio.h>
#include<string.h>
#include <stdlib.h>


void main()
{
    char str[100]; /* Declares a string of size 100 */
    int i,l;
	
       printf("Input the string : ");
       fgets(str, sizeof str, stdin);
       l=strlen(str);
	   printf("The characters of the string in reverse order are : \n");
       for(i=l;i>=0;i--)
       {
       printf("%c  ", str[i]);
       
    }
    printf("\n");
}