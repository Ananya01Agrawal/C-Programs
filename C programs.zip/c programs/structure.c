// structure=it is derived datatype and it is a collection of hetrogenous elements
// syntax
/*struct structurename
{
    datatype1 mem1;
    datatype2 mem2;
    '
    datatypen memn;
}
//syntax of variable declaration of a structure
//struct structure varname;*/
// how to access the member of a structure
// syntax- varname.memname
// every structure should be declared globally
//typedef;it is used to give a new name to the existing type(aliasing)
#include<stdio.h>
int main()
{
    /*typedef int i;// int and i here both are working the same
    int a=5;
    i b=6;
    printf("%d %d",a,b);
    return 0;*/
     struct // annonous structure ; structure without any name used only for temporary purpose
   // struct student

    {
        char name[30];
        int rollnumber;
        char course[30];
        char addresss[30];
        char gender;

    }
    stu;
    //stu={"ananya agrawal",2115800002,"B.Tech CSE honors","mathura",'female'};
    //struct stu2={"ananya agrawal",2115800002,"B.Tech CSE honors","mathura",'female'};
    stu stu1={"ananya agrawal",2115800002,"B.Tech CSE honors","mathura",'female'};
    stu stu2=stu1;//this will copies all the data to stu2
    /*typedef struct student st;
    //compile time initialization
    struct student stu={"ananya agrawal",2115800002,"B.Tech CSE honors","mathura",'female'};
    struct student stu2;*/
    printf("%s %d %s %s %c\n",stu1.name,stu1.rollnumber,stu1.course,stu1.addresss,stu1.gender);
    printf("%s %d %s %s %c\n",stu2.name,stu2.rollnumber,stu2.course,stu2.addresss,stu2.gender);
    // we cannot compare the structure directly we can compare the elements of the structure
    if(stu1==stu2)// error occurs we cannot do like this
    printf("hi");
    else
    printf("hello");
    return 0;
}
// stu var[5,1] comma separsted values
//c 1998