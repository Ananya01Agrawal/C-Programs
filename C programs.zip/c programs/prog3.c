//write a program to find the largest and the smallest word in a string without using nested loops
#include<stdio.h>
int main(){
    int arr
}