// Write a program in C to read n number of values in an array and display it in reverse order.
#include<stdio.h>
void main()
{
    int arr[5],i;
    printf("enter the five elements:");
    for(i=0;i<5;i++){
        scanf("%d",&arr[i]);
        printf("%d",&arr[i]);
    }
    printf("arrays in reverse order:");
    for(i=4;i>=5;i--)
    {
        printf("\n %d reverse lements are = %d:", arr[i]);
    }
}