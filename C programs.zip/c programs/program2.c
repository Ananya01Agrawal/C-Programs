//2.	Write a program in c to store n elements in an array
//And print the elements using pointer.
//(input in main and output in user defined functions)
#include<stdio.h>
int main(){
    printf("enter the number of elements:")
    int n;
    int a[n];
    printf("enter the number of elements of array:")
    {
        for(i=0;i<n;i++)
    }
}
