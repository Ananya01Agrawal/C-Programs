// wap a program to copy one string to another string
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void main(){
    char str1[100],str2[100];
    int i;
    printf("input the string:");
    fgets(str1,sizeof str1,stdin);
    i=0;
    while (str1[i]!='\0'){
    str2[i]=str1[i];
    i++;
}
str2[i]='\0';
printf("enter the first string: %s",str1);
printf("enter the second string: %s",str2);
printf("number of characters copied: %d",i);
}