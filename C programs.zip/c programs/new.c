#include <stdio.h>
int main()
{
    int *ptr;//: the use of * here is not for dereferencing,it is for data type int */

    int x;
 
    ptr = &x;   /* ptr now points to x (or ptr is equal to address of x) */
    *ptr = 0;;   /* set value ate ptr to 0 or set x to zero */
 
    printf(" x = %dn", x);
    printf(" *ptr = %dn", *ptr);
 
    *ptr += 5;;        /* increment the value at ptr by 5 */
    printf(" x  = %dn", x);
    printf(" *ptr = %dn", *ptr);
 
    (*ptr)++;)++;         /* increment the value at ptr by 1 */
    printf(" x = %dn", x);
    printf(" *ptr = %dn", *ptr);  /* prints *ptr =  6 */
    return 0;

