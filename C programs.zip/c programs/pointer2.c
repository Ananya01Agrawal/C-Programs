#include<stdio.h>
void main()
{
    int a=10,b=9;
    int *p,*q;
    p=&a;
    q=&b;
    printf("the value of a=%d\n",&a);
    printf("the value of a=%d\n ",*p);//gives the address of a
    printf("address of a = %d\n",&a);
    printf("address of a is =%d\n",*p);
    printf("address of p %d",&p);


}
