#include<stdio.h>
void main(){
    float a =10, b=11;
    float *p ,*q;//declaration of the pointer
    p=&a;
    q=&b;
    //*q=*p;
    //q=p;
    printf("a = %f %f %f",a ,*p,*q);
}
