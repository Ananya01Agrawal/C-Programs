// wap to input the details of a input(name,roll,address,dob,cc)and display them using the structure.
//take name and dob of structure type.
#include<stdio.h>
struct name{
    char fname[30],mname[30],lname[30];
};
struct date{
    int dd,mm,yy;
};
struct details{
    int roll;
    char addr[100];
    int contact;
    struct name Name;
    struct date Date;
};

int main()
{
    int n,i;
    scanf("%d",&n);
    struct details p[n];
    for(i=0;i<n;i++)
    {
    scanf("%d",&p[i].roll);
    scanf("%s",p[i].addr);
    scanf("%d",&p[i].contact);
    scanf("%s",p[i].Name.fname);
    scanf("%s",p[i].Name.mname);
    scanf("%s",p[i].Name.lname);
    scanf("%d",&p[i].Date.dd);
    scanf("%d",&p[i].Date.mm);
    scanf("%d",&p[i].Date.yy);
}
    for(i=0;i<n;i++)
    printf("%d\n %s\n %d\n %s\n %s\n %s\n %d\n %d\n %d\n",p[i].roll,p[i].addr,p[i].contact,p[i].Name.fname,p[i].Name.mname,p[i].Name.lname,p[i].Date.dd,p[i].Date.mm,p[i].Date.yy);

    return 0;
}

