//design a program to sort an array of intergers without using nested loops
#include<stdio.h>
int main(){
    int               
}