#include<stdio.h>
#include<string.h>
int main(){
    // arrays of pointers
    //to store the address of multiple elements
    char str[]="hello";
    // to declare the array of pointers
    // we cannot store address of different type of elements
    char *p[6];
    for (int i=0;i<6;i++)
    {
        p[i]=str+i;
    }
    for (int i=0;i<6;i++)
    {
        printf("%d",p[i]);
    }

}
