#include<stdio.h>
void main(){
    // string operations
    //string len
    char str[20]="hello";
    int s=sizeof(str)/sizeof(str[0]);
    for(int i=0;str[i]!='\0';i++)
    {
        printf("%c",str[i]);
    }

}
//manually finding the string
int length;
char str[20]="hello";
for(length=0;str[length]!=0;length++)
{
    length++;
}
printf("%d", length)
