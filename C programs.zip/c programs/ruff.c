#include <stdio.h>
int main() 
{ int m,a,b,n,d,r,gcd,lcm;
scanf("%d",&m);
while(m--)
{
    scanf("%d %d",&a,&b);
if(a>b) { n=a; d=b; 
    
} 
else 
{ d=a; n=b; }
r=n%d; while(r!=0)
{ n=d; d=r; r=n%d; }
gcd=d; lcm=(a*b)/gcd;
printf("%d %d\n",gcd,lcm); 
    
} 
return 0; 
    
} 