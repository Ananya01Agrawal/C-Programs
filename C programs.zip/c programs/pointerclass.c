#include<stdio.h>
void main(){
    // pointers nad strings
    char *str="hello";
    //printf("%c",*str);
    // str here holding is the first character(address of first element of tghe string)
    int i;
    int n;
    scanf("%d",&n);
    for (i=0;i<n;i++){
        scanf("%c",(str+i));
    }
    for(i=0;i<n;i++){
        printf(i=0;i<n;i++){
            printf("%c",*(str+i));
        }
    }
    //gets(str);//taking the input from the user
    //printf("%s",str);
    //for (i=0; str[i]!='\0';i++){
    //printf("%c",*(str+i));
    

