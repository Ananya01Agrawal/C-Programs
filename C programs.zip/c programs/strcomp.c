#include<stdio.h>
#include<string.h>
int main()
{
    //string operations
    //string comparison using inbuilt function
    char str1[]="Hello";
    char str2[]="hello";
    printf("%d",strcmp(str1,str2));
    return 0;
}