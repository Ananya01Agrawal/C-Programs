#include<stdio.h>
#include<stdlib.h>
struct student
{
    char*name;
};
struct student s;
struct student fun()
{
    s.name="newton";
    printf("%s\n,s.name");
    s.name="alan";
    return s;

}
int main()
{
    // exercise 2
    struct student m=fun();
    printf("%s\n",m.name);
    m.name="tuning";
    printf("%s\n",s.name);
    return 0;
}
