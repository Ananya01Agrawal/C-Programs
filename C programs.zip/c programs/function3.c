// types of predefined functions
//#include<stdio.h>
//void add()// no return value and no parameters
//{int a,b,sum;
  //  scanf("%d%d",&a,&b);
    //sum=a+b;
    //printf("\nsum is %d",sum);
//}
//int main()// main just only need to call the function
//{
    //add();// function call
//return 0;
//}

//2. function withn return value but no parameter
//#include<stdio.h>
//int add()//with a return value and no parameters
{//
    //int a,b,sum;
    //printf("enter the two integers");
   // scanf("%d %d",&a,&b);//input
    //sum=a+b;
    //return sum;

}
//int main()
{
    //int sum;
    //sum=add();//functionj call
    //printf("\n sum is %d",sum);
    //return 0;
    
}
//3. function with bothn return value and parameter
#include<stdio.h>
int add(int a, int b)//with return value and with parameters
{
    int sum;
    sum=a+b;//operation
    return sum;//return the resulrt
}
int main(){
    int a,b,sum;
    printf("enter the two integers");
   scanf("%d %d",&a,&b);//input
   sum=add(a,b);
   //function call
   printf("/n sum is %d",sum);
   return 0;
}
// 4. function with no return value but parameter
#include<stdio.h>
void add(int a, int b)//no return value and with parameters
{
    int sum;
    sum=a+b;//operation
    return sum;//return the result
}
int main(){
    int a,b,sum;
    printf("enter the two integers");
   scanf("%d %d",&a,&b);//input
   sum=add(a,b);
   //function call
   printf("/n sum is %d",sum);
   return 0;
}
// if we put the function part inside the main function
// function not define in the body even within the main function
//scope of a variable is global by default
//void means it willl not return any value
#include<stdio.h>
int main(){
    int a,b,sum;
    printf("enter the two integers");
   scanf("%d %d",&a,&b);//input
   void add(int a, int b)//no return value and with parameters
{
    int sum;
    sum=a+b;//operation
    return sum;//return the result
}


