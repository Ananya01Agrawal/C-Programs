//write a program to input an character and print its ascii value
#include<stdio.h>
int main(){
    char ch();
    printf("enter the value of character:");
    scanf("%c",&ch );
    printf("%d",&ch);
    return 0;
}