// write a program to check whether aa number is positive or not.
#include<stdio.h>
int main(){
    int a;
    printf("enter the number:");
    scanf("%d",&a);
    if(a>0);
         printf("number is positive");
    elseif (a<0);
          printf("number is negative");
}