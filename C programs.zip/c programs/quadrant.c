#include<stdio.h>  
  
int main()  
{  
    float x, y;  
  
    printf("Enter the point(x, y)\n");  
    scanf("%f%f", &x, &y);  
  
    if(x == 0 && y == 0)  
    {  
        printf("Point lies on the Origin\n");  
    }  
    else if(y == 0 && x > 0)  
    {  
        printf("Point lies on positive x-axis\n");  
    }  
    else if(x == 0 && y > 0)  
    {  
        printf("Point lies on positive y-axis\n");  
    }  
    else if(y == 0 && x < 0)  
    {  
        printf("Point lies on negative x-axis\n");  
    }  
    else if(x == 0 && y < 0)  
    {  
        printf("Point lies on negative y-axis\n");  
    }  
    else if(x > 0 && y > 0)  
    {  
        printf("Point lies in First Quadrant\n");  
    }  
    else if(x < 0 && y > 0)  
    {  
        printf("Point lies in Second Quadrant\n");  
    }  
    else if(x < 0 && y < 0)  
    {  
        printf("Point lies in Third Quadrant\n");  
    }  
    else if(x > 0 && y <0)  
    {  
        printf("Point lies in Forth Quadrant\n");  
    }  
  
    return 0;  
}  