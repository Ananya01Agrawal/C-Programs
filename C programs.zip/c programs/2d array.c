#include<stdio.h>
int main(void)
{
    //2D arrays;
    int a[3][3];
    
    {scanf("%d", &a[i][j]);

    }
    for(int i=0;i<3;i++)//column
    
   { for(int j=0;j<3;j++)//row
    {printf("%d",a[i][j]);
    }}
    printf("/n");
    return 0;
}