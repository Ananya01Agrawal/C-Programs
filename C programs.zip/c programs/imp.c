// statixc and dynamic memory location
//#include<stdio.h>
//#include<stdlib.h>
//void main(){
    
// dynamic memory allocation for that we are having the four functions
 //1. malloc()- used for allocating the memory
//2.calloc()
//3.free()
//int a=5;// runtime when we are execuiting the code
// malloc() memory allocation
// without pointers memory location not possible
// if we wnt to allocate the memory at the run time thenn we will decalare pointer
 // in dynamic memory allocation we will store the address in the form of pointers
//int *p=(int*)malloc(sizeof(int));//just calling then function (we are supplying the number if bytes)
// malloc is a inbuilt function
// memory allocating run time means we are allocating the memory runtime
// memory allocated dynamically means itb always goes in the heap part
// memory of stack it varies from system to system while heap is having more memory than stack
// when pointer is holding the address then it means pointer is pointing to someone or mwwe can say pointer is pointing to variable a
//*p=5;
//}dynamic array and dynamically allocated array are totaly different
//void* malloc(int n)// now void is not limited to any data type
//int n=100;
//int a[n];// dynamic array
//int i;
//for(i=0;i<n;i++){
    //a[i]=i+1;
//}
// how to allocate the memory to array dynamically
//int n=10;
//int *p=malloc(n*sizeof(int));
//int i;
//for(i=0;i<n;n++)
//{
    //*(p+i)=i+1;// *(p+i) can also be written as p[i]
//}

    // calloc()contiguous allocation
    // in malloc we pass only one parameter while in calloc we pass two
#include<stdio.h>
int main(){
    // calloc()contiguous allocation
    //malloc gives the garbage value if we havent initialized while calloc will give the null value
    int*p;
    int i;
    int n=5;
    p=(int*)calloc(n,size of(int));
    if(p==NULL)// if not able to return the value then it will return the null
    {
        printf("\n memory cannot be allocated");
    }
    else{
        for(i=0;i<n;i++)
        p[i]=i+1;
    }
    free(p);//deallocate the memory allocated dynamically
    p=NULL;//if we dont want dangling pointer then we use null
    return 0;
}
       // realloc()function re allocation
       //tralloc used for the extension of  memory
       // a pointer cannot hold another pointer it hold tghe addrfess of a pointer
#include<stdio.h>
int main(){
    int*p;
    int i;
    int n=5;
    p=(int*)calloc(n,sizeof(int));
    if(p==NULL)
    {
        printf("\n memory cannot be allocated");
    }
    else{
        for(i=0;i<n;i++)
        p[i]=i+1;
    }
    int new;
    printf("do you wish to enter few more elements");
    new=10;
    p=(int*)realloc(new,sizeof(int));
    for(i=n;i<new;i++)
    p[i]=i+1;
    return 0;
}
// functions
#include<stdio.h>
void main(){
    int a,b;
    printf("enter the numbers");
    scanf("%d%d",&a,&b);
    printf("sum is %d",add(a,b));
}
       // pointer to a pointer
// a variable which holds the address of another pointer
// we use ** for pointer to a pointer
#include<stdio.h>
void fun(int**p)
{

}
int main()
{
    // pointer to a pointer
    int a=5;//2000
    int *p=&a;//2005
    int **s=&p;//2009
    printf("%d",a);
    printf("\n%d",*p);
    printf("\n%d",(**s));
    return 0;
}
#include<stdio.h>
void fun(int **p)
{

}
int main()
{
  int *p=(int*)malloc(5*sizeof(int));
  fun(p);

  return 0;

// pointer to an array hold the address of the whole array
// pointer to a variable holds the address of a variable
          // pointer to an array
          int a=5;
          int *p=&a;// pointer to a single element
          int a[5];
          int (*ptr)[5];// pointer to multiple elements
          ptr=&a;
          printf("%d",sizeof(*p));
          printf("\n%d",sizeof(*ptr));
           // function pointer
           //hold the address of a pointer
#include<stdio.h>
void fun(int a)
{

}
void (*fun_ptr)(int)=&fun// we put fun_ptr in bracket to specify it is a pointer not a datatype.
(*fun_ptr)();// to call a function with the help of pointers