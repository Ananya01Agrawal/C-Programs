//write a c program to convert clesius into fahrenheit
#include<stdio.h>
int main(){
    int celsius=37, fahrenheit;
    fahrenheit=(celsius*9/5)+32;
    printf("the value of this celsius temperature in fahrenheit is %f", fahrenheit);
    return 0;

}