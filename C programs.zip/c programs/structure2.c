#include<stdio.h>
#include<stdlib.h>
struct A{
int a;
float b;
char c[4];
};
int main()
{
    // exercise 1
    // variable name of a structure are not the pointers
    // how pointer arithmetic on structures differ from pointer arithmetic on arrays in c
struct A x={10,23.33,"hi"},y={12,25.55,"hi"};
struct A *ptr2x=&x;//ptr2x is pointing to structure variable 'x'
printf("%x %x %x %x\n",&x,&y,ptr2x,(ptr2x+1));
printf("%d",(*ptr2x).a);
printf("\n%d",(*(ptr2x+1)).a);
return 0;
}