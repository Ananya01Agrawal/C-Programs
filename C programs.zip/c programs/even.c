//program to check given number is even or odd
#include <stdio.h>

int main() {

    int number;

    printf("Enter an integer : ");
    scanf("%d", &number);

    if (number % 2 == 0) {

        printf("\n%d is even number.", number);

    } else {

        printf("\n%d is odd number.", number);
    }

    return 0;
}
