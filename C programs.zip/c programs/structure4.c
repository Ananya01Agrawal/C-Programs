#include<stdio.h>
#include<stdlib.h>
struct student
{
    char*name;
};
struct student s;
struct student fun()
{
    s.name="newton";
    printf("%s\n,s.name");
    s.name="alan";
    return s;

}
int main()
{
    // exercise 3
    // copying the both the srtructures
    struct student s,m;
    s.name="st";
    m=s;
    printf("%s %s",s.name,m.name);
    
    return 0;
}
struct temp
{
    int a;
}s;
void func(struct temp s)
{
    s.a=10
    printf("%d\t",s.a);
    }
    // exercise 4
    int main(){
    func(s);
    printf("%d\t",s.a);
    return 0;
};
struct student fun(void)
{
    struct student s;
    s.name="alan";
    return s;

}
