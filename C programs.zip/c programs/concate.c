// write a program to copy one concatente two given strings without using inbuilt function

#include<stdio.h>
#include<string.h>
int main(){
    char str1[];
    char str2[];
    printf("enter first string");
    scanf("%s",str1);
    printf("enter the second string");
    scanf("%s",str2);

}