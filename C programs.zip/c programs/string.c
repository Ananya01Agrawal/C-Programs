#include<stdio.h>
int main()
{
    // stringsin c 
    char str1[20]="how you doing!";
   
    printf("%c",&str1[5]+5);
    

    return 0;
}