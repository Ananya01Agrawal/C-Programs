//1.	Write a program in c to add two numbers using pointers.
//( input in main and output in main)
//(addition in user defined functions)

#include <stdio.h>
int sum(int *a,int *b)
{
  int s=*a+*b;
  return s;
}
int main()
{
    printf("ENTER TWO NUMBERS");
    int a,b;
    scanf("%d %d",&a,&b);
    printf("sum=%d",sum(&a,&b));

    return 0;
}