// write a program to add two numbers in c
#include<stdio.h>
int main()
{
    int a, b, sum;
    printf("enter the first number");
    scanf("%d",&a);
    printf("enter the second number");
    scanf("%d",&b);
    sum=a+b;
    printf("the sum of two numbers is %d",&sum);
    return 0;

}
