// write a c program to calculate the simple interest.
#include<stdio.h>
int main(){
    int s,r,t,si;
    printf("enter the principle value:");
    scanf("%d", s);
    printf("enter the rate at which they want to take:");
    scanf("%d",r);
    printf("enter the no of years");
    scanf("%d",t);
    si=(s*r*t)/100;
    printf("the value of simple interest is %d", si);
    return 0;
}