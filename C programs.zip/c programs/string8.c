#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void main(){
    char str[100];
    int i,vow,cons,len;
    printf("enter the string:");
    fgets(str,sizeof str,stdin);
    len=strlen(str);
    vow=0;
    cons=0;
    for(i=0;i<=len;i++){
        if(str[i]=='a'||str[i])=='e' ||str[i]=='i'||str[i]=='o'||str[i]=='u'||str[i]=='A'||str[i]=='E'||str[i]=='O'||str[i]=='U')
        vow++;
        else if{
            ((str[i]>='a'&& str[i]<='z')||(str[i]>='A'&& str[i]<='Z'))
            cons++;
        }
    }
    printf("the total number of vowels in the string:%d\n",vow);
    printf("the total number of consonamt:%d",cons);
}