//write a program to input two numbers and swap them.
#include<stdio.h>
int main(){
    int a,b,c,d;
    printf("enter the two numbers:");
    scanf("%d %d",&a,&b);
    printf("initial value of a is %d and initial value of b is %d", a,b);
    c=a;
    a=b;
    b=c;
    printf("the awapped value a is %d and swapped value of b is %d", d,c);
    return 0;
}