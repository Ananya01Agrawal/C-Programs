//printf out[put the value on the screen]
//scanf receives input from the keyboard
// basic structure of c program
// ampersand (&) is an address of an operator .it gives the location number used by the variable
// in memory
// modulus operator cannot be applied on float
// when the expression contain two or more than two operator of same precedence
// then we go for associativity .(left to right)/(right to left)
// a variable name can be of maximum 31 characters
//= used as assignment operator and == is used for comaprison of two operators

#include<stdio.h>
int main(){
    int p,n;
    float r,si;
    printf("enter the values of p,n,r");
    scanf("%d %d %f",&p,&n,&r);

    si=p*n*r/100;
    printf("%f",si);
}
// a demo of nested if else loop//
#include<stdio.h>
void main()
{
    int 1;
    printf("enter either 1 or 2")
    scanf("%d",&i);
    if(i==1)
    printf("you would go to heaven");
    else{
        if(i==2)
        printf("hell was created with you in mind");
        else
        printf("how about the mother earth");
    }

}