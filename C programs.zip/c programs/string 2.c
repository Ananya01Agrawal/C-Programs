// wap in c to find the length of a string without using library function
#include<stdio.h>
#include<stdlib.h>
void main(){
    char str[50];
    int length=0;
    printf("enter the string");
    fgets(str, sizeof str, stdin);
    while(str[length]!='\0'){
        length++;
    }
    printf("length of the string:%d",length-1);
}
