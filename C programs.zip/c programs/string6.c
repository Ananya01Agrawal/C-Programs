// write a program in c to count the total number of alphabets ,digits and special characters
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void main(){
    char str[100];
    int alph,digit,spch,i;
    printf("enter the string:");
    fgets(str,sizeof str,stdin);
    while (str[i]!='0')
    {
        if((str[i]>='a'&&str[i]<='z')||(str[i]>='A'&& str[i]<='Z'))
        {
            alph++;
        }
        else if((str[i]>='0'&&str[i]<='9'))
        {
            digit++;
        }
        else
        {
            spch++;
        }
        i++;
    }
    printf("number of alphabets in the string is :%d",alph);
    printf("number of digits in the string:%d",digit);
    printf("number of special character in the string:%d",spch);
}
